﻿using Microsoft.IdentityModel.Tokens; 
using System.Diagnostics.CodeAnalysis;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace TestNet7.BAL
{
    public class Jwt     
    {
        private IConfiguration _config;
        public Jwt(IConfiguration config)
        {
            _config = config;

        }
        public string Generate()
        {
            var claims = new Claim[]
            {
                new(ClaimTypes.Name, "RandomName"),
                new(JwtRegisteredClaimNames.Email,  "abc@gmail.com")
            };

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("DhftOS5uphK3vmCJQrexST1RsyjZBjXWRgJMFPU4"));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            
           

            var token = new JwtSecurityToken(
              "http://localhost:63626/",
              "http://localhost:63626/",
              claims,
              null,
              expires: DateTime.Now.AddMinutes(10),
              credentials
              );
             return new JwtSecurityTokenHandler().WriteToken(token);
    
        }
    }
}
